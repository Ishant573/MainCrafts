import { NavLink, Outlet, Link } from "react-router-dom";
import { useState } from "react";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export default function Layout() {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 antialiased">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-stone-200/70 bg-stone-50/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link to="/" className="flex items-center gap-2 group">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-amber-400 to-rose-500 text-white shadow-sm shadow-rose-200 transition-transform group-hover:scale-105">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="4" />
                <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
              </svg>
            </span>
            <span className="text-lg font-semibold tracking-tight">Lumen<span className="text-rose-500">.</span></span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-1 md:flex">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                className={({ isActive }) =>
                  `rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-stone-900 text-white"
                      : "text-stone-600 hover:bg-stone-200/70 hover:text-stone-900"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <Link
            to="/contact"
            className="hidden rounded-full bg-rose-500 px-5 py-2 text-sm font-medium text-white shadow-sm shadow-rose-200 transition hover:bg-rose-600 md:inline-block"
          >
            Start a project
          </Link>

          {/* Mobile menu button */}
          <button
            onClick={() => setOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-lg text-stone-700 hover:bg-stone-200/70 md:hidden"
            aria-label="Toggle menu"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
              {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>

        {/* Mobile nav */}
        {open && (
          <div className="border-t border-stone-200 bg-stone-50 md:hidden">
            <nav className="mx-auto flex max-w-6xl flex-col px-6 py-3">
              {navItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === "/"}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    `rounded-lg px-3 py-3 text-sm font-medium ${
                      isActive ? "bg-stone-900 text-white" : "text-stone-700 hover:bg-stone-200"
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>
          </div>
        )}
      </header>

      {/* Page content */}
      <main>
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="mt-24 border-t border-stone-200 bg-white">
        <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-amber-400 to-rose-500 text-white">
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2.2}>
                  <circle cx="12" cy="12" r="4" />
                </svg>
              </span>
              <span className="font-semibold">Lumen Studio</span>
            </div>
            <p className="mt-4 max-w-sm text-sm text-stone-600">
              A small design studio crafting calm, considered brands and digital
              experiences for ambitious teams worldwide.
            </p>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-stone-900">Pages</h4>
            <ul className="mt-4 space-y-2 text-sm text-stone-600">
              {navItems.map((i) => (
                <li key={i.to}>
                  <Link to={i.to} className="hover:text-rose-500">{i.label}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-stone-900">Elsewhere</h4>
            <ul className="mt-4 space-y-2 text-sm text-stone-600">
              <li><a href="#" className="hover:text-rose-500">Dribbble</a></li>
              <li><a href="#" className="hover:text-rose-500">Instagram</a></li>
              <li><a href="#" className="hover:text-rose-500">LinkedIn</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-stone-200">
          <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-6 py-5 text-xs text-stone-500 sm:flex-row">
            <p>© {new Date().getFullYear()} Lumen Studio. All rights reserved.</p>
            <p>Made with care in Lisbon.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
