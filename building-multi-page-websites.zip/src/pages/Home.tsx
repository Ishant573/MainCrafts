import { Link } from "react-router-dom";

const services = [
  {
    title: "Brand Identity",
    desc: "Logos, typography systems, and visual languages that feel inevitable.",
    icon: (
      <path d="M12 2l2.39 4.84L19.8 7.6l-3.9 3.8.92 5.36L12 14.27l-4.82 2.49.92-5.36-3.9-3.8 5.41-.76L12 2z" />
    ),
  },
  {
    title: "Web Design",
    desc: "Beautiful, fast, and accessible sites built with modern tools.",
    icon: (
      <>
        <rect x="3" y="4" width="18" height="14" rx="2" />
        <path d="M3 9h18M8 18v3M16 18v3M7 21h10" />
      </>
    ),
  },
  {
    title: "Product Design",
    desc: "From discovery to launch — interfaces people actually enjoy using.",
    icon: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M8 12h8M12 8v8" />
      </>
    ),
  },
];

const projects = [
  { name: "Mira Coffee", tag: "Brand · Packaging", from: "from-amber-200", to: "to-orange-300" },
  { name: "Northwind Bank", tag: "Product · Web", from: "from-sky-200", to: "to-indigo-300" },
  { name: "Field Notes", tag: "Editorial · Print", from: "from-emerald-200", to: "to-teal-300" },
  { name: "Atlas Travel", tag: "Brand · Web", from: "from-rose-200", to: "to-pink-300" },
];

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-amber-50 via-stone-50 to-stone-50" />
        <div className="absolute -top-32 -right-32 -z-10 h-96 w-96 rounded-full bg-rose-200/40 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 -z-10 h-96 w-96 rounded-full bg-amber-200/40 blur-3xl" />

        <div className="mx-auto max-w-6xl px-6 pt-20 pb-24 md:pt-28 md:pb-32">
          <span className="inline-flex items-center gap-2 rounded-full border border-stone-200 bg-white/70 px-3 py-1 text-xs font-medium text-stone-600 backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
            Booking projects for Q3 2026
          </span>
          <h1 className="mt-6 max-w-3xl text-5xl font-semibold leading-[1.05] tracking-tight text-stone-900 md:text-7xl">
            Design that <span className="italic text-rose-500">moves</span> people, not pixels.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-stone-600">
            We're Lumen — a tiny independent studio helping ambitious teams ship
            calm, considered brands and digital products.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              to="/contact"
              className="rounded-full bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-700"
            >
              Start a project →
            </Link>
            <Link
              to="/about"
              className="rounded-full border border-stone-300 bg-white px-6 py-3 text-sm font-medium text-stone-700 transition hover:border-stone-900"
            >
              Meet the studio
            </Link>
          </div>

          {/* Logos */}
          <div className="mt-16 flex flex-wrap items-center gap-x-10 gap-y-4 text-sm text-stone-400">
            <span className="text-xs uppercase tracking-widest">Trusted by</span>
            {["Northwind", "Atlas", "Mira", "Field Co.", "Linear", "Helio"].map((l) => (
              <span key={l} className="font-medium">{l}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="text-sm font-medium text-rose-500">What we do</p>
            <h2 className="mt-2 max-w-xl text-4xl font-semibold tracking-tight">
              Small studio. Wide range.
            </h2>
          </div>
          <p className="max-w-md text-stone-600">
            Three core practices, woven together when needed. Every engagement is
            led by a senior designer from day one.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {services.map((s) => (
            <div
              key={s.title}
              className="group rounded-3xl border border-stone-200 bg-white p-7 transition hover:border-stone-900 hover:shadow-lg hover:shadow-stone-200/50"
            >
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-stone-100 text-stone-700 transition group-hover:bg-rose-500 group-hover:text-white">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
                  {s.icon}
                </svg>
              </span>
              <h3 className="mt-5 text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-stone-600">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Selected Work */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="flex items-end justify-between">
          <div>
            <p className="text-sm font-medium text-rose-500">Selected work</p>
            <h2 className="mt-2 text-4xl font-semibold tracking-tight">Recent projects</h2>
          </div>
          <Link to="/about" className="hidden text-sm font-medium text-stone-700 underline-offset-4 hover:underline md:block">
            View all →
          </Link>
        </div>

        <div className="mt-10 grid gap-6 sm:grid-cols-2">
          {projects.map((p) => (
            <a
              key={p.name}
              href="#"
              className="group block overflow-hidden rounded-3xl border border-stone-200 bg-white transition hover:-translate-y-1 hover:shadow-xl hover:shadow-stone-200/60"
            >
              <div className={`relative aspect-[4/3] bg-gradient-to-br ${p.from} ${p.to} overflow-hidden`}>
                <div className="absolute inset-0 opacity-30 mix-blend-overlay" style={{ backgroundImage: "radial-gradient(circle at 30% 20%, white, transparent 50%)" }} />
                <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                  <span className="rounded-full bg-white/90 px-3 py-1 text-xs font-medium text-stone-800 backdrop-blur">
                    Case study
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between p-5">
                <div>
                  <h3 className="font-semibold">{p.name}</h3>
                  <p className="text-sm text-stone-500">{p.tag}</p>
                </div>
                <span className="text-stone-400 transition group-hover:translate-x-1 group-hover:text-rose-500">→</span>
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-6 pb-20">
        <div className="relative overflow-hidden rounded-3xl bg-stone-900 px-8 py-16 text-center text-white md:px-16 md:py-20">
          <div className="absolute -top-20 -left-20 h-64 w-64 rounded-full bg-rose-500/30 blur-3xl" />
          <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-amber-400/20 blur-3xl" />
          <h2 className="relative text-3xl font-semibold tracking-tight md:text-5xl">
            Have a project in mind?
          </h2>
          <p className="relative mx-auto mt-4 max-w-lg text-stone-300">
            We take on a handful of clients each quarter. Tell us about your idea —
            we'll reply within two business days.
          </p>
          <Link
            to="/contact"
            className="relative mt-8 inline-block rounded-full bg-white px-6 py-3 text-sm font-medium text-stone-900 transition hover:bg-stone-100"
          >
            Get in touch
          </Link>
        </div>
      </section>
    </div>
  );
}
