const team = [
  { name: "Inês Carvalho", role: "Founder · Design Director", initials: "IC", color: "from-rose-300 to-pink-400" },
  { name: "Lukas Müller", role: "Lead Product Designer", initials: "LM", color: "from-amber-300 to-orange-400" },
  { name: "Aoife Donnelly", role: "Brand Designer", initials: "AD", color: "from-emerald-300 to-teal-400" },
  { name: "Rafael Souza", role: "Engineer", initials: "RS", color: "from-sky-300 to-indigo-400" },
];

const values = [
  { title: "Calm by default", desc: "We work at a steady, sustainable pace. Good work needs room to breathe." },
  { title: "Craft over speed", desc: "Details aren't decoration — they're the work. We sweat them." },
  { title: "Honest partnership", desc: "No layers, no spin. You talk to the people doing the work." },
  { title: "Useful, not loud", desc: "Design should serve people, not designers' portfolios." },
];

const timeline = [
  { year: "2019", title: "Lumen begins", desc: "Inês starts the studio from a small apartment in Lisbon." },
  { year: "2021", title: "First product launch", desc: "We ship our first end-to-end product for a fintech client." },
  { year: "2023", title: "The team grows", desc: "Lukas, Aoife, and Rafael join. We move into a sunlit studio." },
  { year: "2026", title: "Today", desc: "A team of four, working with clients across three continents." },
];

export default function About() {
  return (
    <div>
      {/* Intro */}
      <section className="relative overflow-hidden border-b border-stone-200">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-stone-100 to-stone-50" />
        <div className="mx-auto max-w-6xl px-6 py-20 md:py-28">
          <p className="text-sm font-medium text-rose-500">About us</p>
          <h1 className="mt-3 max-w-3xl text-5xl font-semibold leading-tight tracking-tight md:text-6xl">
            A small studio with a quiet obsession for craft.
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-stone-600">
            Lumen is an independent design studio of four. We partner with founders,
            product teams, and cultural institutions to shape the brands, websites,
            and products they're proud to put their name on.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="grid gap-8 sm:grid-cols-3">
          {[
            { n: "60+", l: "Projects delivered" },
            { n: "4", l: "People in the studio" },
            { n: "7 yrs", l: "Designing together" },
          ].map((s) => (
            <div key={s.l} className="rounded-2xl border border-stone-200 bg-white p-8">
              <div className="text-5xl font-semibold tracking-tight text-stone-900">{s.n}</div>
              <div className="mt-2 text-sm text-stone-500">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Values */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-[1fr_2fr]">
          <div>
            <p className="text-sm font-medium text-rose-500">What we believe</p>
            <h2 className="mt-2 text-4xl font-semibold tracking-tight">Our values</h2>
            <p className="mt-4 text-stone-600">
              The principles that guide how we work, hire, and choose projects.
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2">
            {values.map((v) => (
              <div key={v.title} className="rounded-2xl border border-stone-200 bg-white p-6">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-rose-500" />
                  <h3 className="font-semibold">{v.title}</h3>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-stone-600">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <p className="text-sm font-medium text-rose-500">The team</p>
        <h2 className="mt-2 text-4xl font-semibold tracking-tight">Four humans, one studio</h2>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {team.map((p) => (
            <div key={p.name} className="rounded-2xl border border-stone-200 bg-white p-6 text-center">
              <div className={`mx-auto grid h-24 w-24 place-items-center rounded-full bg-gradient-to-br ${p.color} text-2xl font-semibold text-white shadow-inner`}>
                {p.initials}
              </div>
              <h3 className="mt-5 font-semibold">{p.name}</h3>
              <p className="mt-1 text-sm text-stone-500">{p.role}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Timeline */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <p className="text-sm font-medium text-rose-500">The story</p>
        <h2 className="mt-2 text-4xl font-semibold tracking-tight">A short history</h2>

        <div className="relative mt-10 border-l-2 border-stone-200 pl-8">
          {timeline.map((t) => (
            <div key={t.year} className="relative pb-10 last:pb-0">
              <span className="absolute -left-[41px] grid h-5 w-5 place-items-center rounded-full bg-rose-500 ring-4 ring-stone-50">
                <span className="h-1.5 w-1.5 rounded-full bg-white" />
              </span>
              <div className="text-sm font-medium text-rose-500">{t.year}</div>
              <h3 className="mt-1 text-xl font-semibold">{t.title}</h3>
              <p className="mt-1 max-w-lg text-stone-600">{t.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
