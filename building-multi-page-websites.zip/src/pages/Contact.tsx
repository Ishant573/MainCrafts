import { useState, FormEvent } from "react";

type FormState = {
  name: string;
  email: string;
  budget: string;
  message: string;
};

const initial: FormState = { name: "", email: "", budget: "", message: "" };

export default function Contact() {
  const [form, setForm] = useState<FormState>(initial);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Partial<FormState>>({});

  function validate(f: FormState) {
    const e: Partial<FormState> = {};
    if (!f.name.trim()) e.name = "Please tell us your name.";
    if (!f.email.trim()) e.email = "An email helps us reply.";
    else if (!/^\S+@\S+\.\S+$/.test(f.email)) e.email = "That doesn't look like an email.";
    if (!f.message.trim() || f.message.trim().length < 10)
      e.message = "Tell us a little more (10+ characters).";
    return e;
  }

  function onSubmit(ev: FormEvent<HTMLFormElement>) {
    ev.preventDefault();
    const e = validate(form);
    setErrors(e);
    if (Object.keys(e).length === 0) {
      setSubmitted(true);
    }
  }

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div>
      {/* Header */}
      <section className="relative overflow-hidden border-b border-stone-200">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-rose-50 via-stone-50 to-stone-50" />
        <div className="mx-auto max-w-6xl px-6 py-20 md:py-24">
          <p className="text-sm font-medium text-rose-500">Contact</p>
          <h1 className="mt-3 max-w-3xl text-5xl font-semibold leading-tight tracking-tight md:text-6xl">
            Let's make something good together.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-stone-600">
            Have a project, a question, or just want to say hello? Drop us a line —
            we read every message and reply within two business days.
          </p>
        </div>
      </section>

      {/* Form + info */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr]">
          {/* Form */}
          <div className="rounded-3xl border border-stone-200 bg-white p-8 md:p-10">
            {submitted ? (
              <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                <div className="grid h-16 w-16 place-items-center rounded-full bg-emerald-100 text-emerald-600">
                  <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                    <path d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="mt-6 text-2xl font-semibold">Thanks, {form.name.split(" ")[0]}!</h2>
                <p className="mt-2 max-w-sm text-stone-600">
                  Your message is on its way. We'll be in touch at <span className="font-medium text-stone-900">{form.email}</span> shortly.
                </p>
                <button
                  onClick={() => {
                    setForm(initial);
                    setSubmitted(false);
                  }}
                  className="mt-8 rounded-full border border-stone-300 px-5 py-2 text-sm font-medium text-stone-700 hover:border-stone-900"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-6" noValidate>
                <div className="grid gap-6 sm:grid-cols-2">
                  <Field
                    label="Your name"
                    error={errors.name}
                    input={
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => update("name", e.target.value)}
                        placeholder="Jane Doe"
                        className="w-full rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-stone-900 focus:ring-2 focus:ring-stone-900/10"
                      />
                    }
                  />
                  <Field
                    label="Email"
                    error={errors.email}
                    input={
                      <input
                        type="email"
                        value={form.email}
                        onChange={(e) => update("email", e.target.value)}
                        placeholder="jane@company.com"
                        className="w-full rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-stone-900 focus:ring-2 focus:ring-stone-900/10"
                      />
                    }
                  />
                </div>

                <Field
                  label="Budget (optional)"
                  input={
                    <select
                      value={form.budget}
                      onChange={(e) => update("budget", e.target.value)}
                      className="w-full rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-stone-900 focus:ring-2 focus:ring-stone-900/10"
                    >
                      <option value="">Select a range</option>
                      <option>Under $10k</option>
                      <option>$10k – $25k</option>
                      <option>$25k – $50k</option>
                      <option>$50k+</option>
                    </select>
                  }
                />

                <Field
                  label="Tell us about your project"
                  error={errors.message}
                  input={
                    <textarea
                      value={form.message}
                      onChange={(e) => update("message", e.target.value)}
                      rows={6}
                      placeholder="A few sentences about what you're working on, your goals, and your timeline."
                      className="w-full resize-none rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-stone-900 focus:ring-2 focus:ring-stone-900/10"
                    />
                  }
                />

                <div className="flex items-center justify-between pt-2">
                  <p className="text-xs text-stone-500">We'll never share your details.</p>
                  <button
                    type="submit"
                    className="rounded-full bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-700"
                  >
                    Send message →
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Contact info */}
          <aside className="space-y-6">
            <InfoCard
              title="Email"
              value="hello@lumenstudio.co"
              note="Best for project inquiries"
              icon={
                <>
                  <rect x="3" y="5" width="18" height="14" rx="2" />
                  <path d="M3 7l9 6 9-6" />
                </>
              }
            />
            <InfoCard
              title="Studio"
              value="Rua das Flores 23, Lisbon"
              note="Visits by appointment"
              icon={
                <>
                  <path d="M12 22s-7-7.58-7-12a7 7 0 0114 0c0 4.42-7 12-7 12z" />
                  <circle cx="12" cy="10" r="2.5" />
                </>
              }
            />
            <InfoCard
              title="Hours"
              value="Mon – Fri, 9–18 WET"
              note="Weekends offline, on purpose"
              icon={
                <>
                  <circle cx="12" cy="12" r="9" />
                  <path d="M12 7v5l3 2" />
                </>
              }
            />

            <div className="rounded-3xl border border-stone-200 bg-stone-900 p-6 text-stone-200">
              <h3 className="font-semibold text-white">Prefer a call?</h3>
              <p className="mt-2 text-sm">
                Book a free 20-minute intro on our calendar — we'll talk through
                your project and see if we're a fit.
              </p>
              <a
                href="#"
                className="mt-4 inline-block rounded-full bg-white px-4 py-2 text-sm font-medium text-stone-900 transition hover:bg-stone-100"
              >
                Book a call
              </a>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

function Field({
  label,
  input,
  error,
}: {
  label: string;
  input: React.ReactNode;
  error?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-medium text-stone-700">{label}</span>
      {input}
      {error && <span className="mt-1.5 block text-xs text-rose-600">{error}</span>}
    </label>
  );
}

function InfoCard({
  title,
  value,
  note,
  icon,
}: {
  title: string;
  value: string;
  note: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-stone-200 bg-white p-6">
      <div className="flex items-start gap-4">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-rose-50 text-rose-500">
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            {icon}
          </svg>
        </span>
        <div>
          <h3 className="text-sm font-medium text-stone-500">{title}</h3>
          <p className="mt-1 font-semibold text-stone-900">{value}</p>
          <p className="mt-1 text-xs text-stone-500">{note}</p>
        </div>
      </div>
    </div>
  );
}
