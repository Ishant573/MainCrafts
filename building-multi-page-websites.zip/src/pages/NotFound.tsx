import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <section className="mx-auto flex max-w-3xl flex-col items-center px-6 py-32 text-center">
      <p className="text-sm font-medium text-rose-500">404</p>
      <h1 className="mt-3 text-5xl font-semibold tracking-tight md:text-6xl">
        We can't find that page.
      </h1>
      <p className="mt-4 max-w-md text-stone-600">
        The page you're looking for has moved, or maybe never existed. Let's get
        you back on track.
      </p>
      <Link
        to="/"
        className="mt-8 rounded-full bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-700"
      >
        Take me home
      </Link>
    </section>
  );
}
